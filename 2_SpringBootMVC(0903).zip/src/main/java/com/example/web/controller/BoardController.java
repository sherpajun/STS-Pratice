package com.example.web.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import com.example.web.service.BoardService;
import com.example.web.vo.Board;

@Controller
public class BoardController {

	@Autowired
	BoardService boardService;

	@GetMapping("/boardList")
	public String boardList(Model model) {
		System.out.println(1);
		List<Board> list = boardService.boardList();
		model.addAttribute("articlesList",list);
		return "test";//"boardList";
	}

}
